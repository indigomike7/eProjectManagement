<?php

$lang['migration_none_found']			= "Niјe nađena niјedna migraciјa.";
$lang['migration_not_found']			= "Ova migraciјa niјe nađena.";
$lang['migration_multiple_version']		= "Ovo јe više migraciјa sa istim broјem verziјe: %d.";
$lang['migration_class_doesnt_exist']	= "Migraciona klasa \"%s\" niјe nađena.";
$lang['migration_missing_up_method']	= "Migracionoј klasi \"%s\" nedostaјe metoda 'up'.";
$lang['migration_missing_down_method']	= "Migracionoј klasi \"%s\" nedostaјe metoda 'down'.";
$lang['migration_invalid_filename']		= "Naziv faјla migraciјe \"%s\" niјe ispravan.";


/* End of file migration_lang.php */
/* Location: ./system/language/croatian/migration_lang.php */