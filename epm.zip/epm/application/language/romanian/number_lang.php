<?php

$lang['terabyte_abbr'] = "TB";
$lang['gigabyte_abbr'] = "GB";
$lang['megabyte_abbr'] = "MB";
$lang['kilobyte_abbr'] = "KB";
$lang['bytes'] = "Biţi";

/* End of file number_lang.php */
/* Location: ./system/language/romanian/number_lang.php */
