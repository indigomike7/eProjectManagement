<?php

$lang['terabyte_abbr'] = "To";
$lang['gigabyte_abbr'] = "Go";
$lang['megabyte_abbr'] = "Mo";
$lang['kilobyte_abbr'] = "Ko";
$lang['bytes'] = "octets";

/* End of file number_lang.php */
/* Location: ./system/language/french/number_lang.php */