<?php
$lang['migration_none_found'] = 'Δεν βρέθηκαν μεταναστεύσεις.';
$lang['migration_not_found'] = 'Δεν ήταν δυνατή η εύρεση αυτής της μετανάστευσης.';
$lang['migration_multiple_version'] = 'Υπάρχουν πολλαπλές μεταναστεύσεις με τον ίδιο αριθμό έκδοσης: %d.';
$lang['migration_class_doesnt_exist'] = 'Η κλάση μετανάστευσης δεν υπάρχει';
$lang['migration_missing_up_method'] = 'Η κλάση μετανάστευσης δεν έχει μέθοδο UP';
$lang['migration_missing_down_method'] = 'Η κλάση μετανάστευσης δεν έχει μέθοδο DOWN';
$lang['migration_invalid_filename'] = 'Λάθος όνομα αρχείου μετανάστευσης';

/* End of file migration_lang.php */
/* Location: ./application/language/greek/migration_lang.php */
