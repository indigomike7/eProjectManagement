<?php

$lang['migration_none_found']			= "没有发现迁移。";
$lang['migration_not_found']			= "这个迁移无法发现。";
$lang['migration_multiple_version']		= "这个多迁移拥有相同的版本号: %d.";
$lang['migration_class_doesnt_exist']	= "这个迁移类 \"%s\" 无法发现。";
$lang['migration_missing_up_method']	= "这个迁移类 \"%s\" 缺失一个'up'方法。";
$lang['migration_missing_down_method']	= "这个迁移类 \"%s\" 缺失一个'down'方法。";
$lang['migration_invalid_filename']		= "迁移 \"%s\" 的文件名无效。";


/* End of file migration_lang.php */
/* Location: ./system/language/chinese/migration_lang.php */
