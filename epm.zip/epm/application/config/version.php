<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$config['version'] = '1.7.5';
/* End of file version.php */